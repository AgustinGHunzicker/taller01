CREATE TABLE public.capitulo
(
  nombre_capitulo character varying NOT NULL,
  id_material integer NOT NULL,
  secciones character varying[],
  id_capitulo integer,
  id_metadatoweb integer
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.capitulo
  OWNER TO postgres;
