CREATE TABLE public.resumen
(
  id_material integer NOT NULL,
  parrafos character varying[]
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.resumen
  OWNER TO postgres;
