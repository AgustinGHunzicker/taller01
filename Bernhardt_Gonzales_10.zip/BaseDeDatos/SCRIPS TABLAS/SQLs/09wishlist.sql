CREATE TABLE public.wishlist
(
  id_material integer,
  titulo character varying,
  tema character varying,
  fecha_publicacion date,
  calificacion integer,
  relevancia double precision,
  costo double precision,
  pag_dur integer,
  precio_o_costo double precision,
  CONSTRAINT id_uniq UNIQUE (id_material)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.wishlist
  OWNER TO postgres;
