CREATE TABLE public.seccion
(
  id_material integer NOT NULL,
  id_seccion integer,
  id_capitulo integer,
  parrafos character varying[]
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.seccion
  OWNER TO postgres;
