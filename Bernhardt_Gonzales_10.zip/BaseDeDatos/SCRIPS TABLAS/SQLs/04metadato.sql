CREATE TABLE public.metadato
(
  id_material integer NOT NULL,
  editorial character varying,
  fecha_publicacion date,
  autores character varying[],
  palabras_claves character varying[],
  CONSTRAINT metadato_pk PRIMARY KEY (id_material)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.metadato
  OWNER TO postgres;
