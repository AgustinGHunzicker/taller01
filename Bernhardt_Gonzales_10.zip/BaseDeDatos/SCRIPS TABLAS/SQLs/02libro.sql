CREATE TABLE public.libro
(
  id_material integer NOT NULL,
  fecha_publicacion date NOT NULL,
  costo double precision,
  paginas integer,
  precio_compra double precision,
-- Inherited from table material_capacitacion:  titulo character varying,
-- Inherited from table material_capacitacion:  tema character varying,
-- Inherited from table material_capacitacion:  calificacion integer,
-- Inherited from table material_capacitacion:  relacion_entrada integer[],
-- Inherited from table material_capacitacion:  relacion_salida integer[],
-- Inherited from table material_capacitacion:  relevancia double precision,
  CONSTRAINT libro_pk PRIMARY KEY (id_material, fecha_publicacion)
)
INHERITS (public.material_capacitacion)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.libro
  OWNER TO postgres;
