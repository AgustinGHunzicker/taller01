CREATE TABLE public.metadatoweb
(
  id_material integer NOT NULL,
  palabras_claves character varying[],
  id_capitulo integer,
  sitios_web character varying[],
  sitios_web_ejercidos character varying[]
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.metadatoweb
  OWNER TO postgres;
