CREATE TABLE public.material_capacitacion
(
  id_material integer NOT NULL,
  costo double precision,
  fecha_publicacion date NOT NULL,
  titulo character varying,
  tema character varying,
  calificacion integer, -- va de 0 a 100
  relacion_entrada integer[],
  relacion_salida integer[],
  relevancia double precision,
  CONSTRAINT material_pk PRIMARY KEY (id_material, fecha_publicacion)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.material_capacitacion
  OWNER TO postgres;
COMMENT ON COLUMN public.material_capacitacion.calificacion IS 'va de 0 a 100 ';

